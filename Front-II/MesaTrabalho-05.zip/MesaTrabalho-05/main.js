let bodyReference = document.querySelector('body')

function switButtonDarkMode(){
    bodyReference.classList.toggle('dark')
    }